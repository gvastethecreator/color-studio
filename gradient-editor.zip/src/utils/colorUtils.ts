import { GradientConfig, GradientStop } from '../types';

// Convert HEX string (e.g. "#ff0000" or "ff0000") to RGB object
export function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const cleanHex = hex.replace(/^#/, '');
  if (cleanHex.length !== 3 && cleanHex.length !== 6) {
    return null;
  }

  let r = 0, g = 0, b = 0;
  if (cleanHex.length === 3) {
    r = parseInt(cleanHex[0] + cleanHex[0], 16);
    g = parseInt(cleanHex[1] + cleanHex[1], 16);
    b = parseInt(cleanHex[2] + cleanHex[2], 16);
  } else {
    r = parseInt(cleanHex.substring(0, 2), 16);
    g = parseInt(cleanHex.substring(2, 4), 16);
    b = parseInt(cleanHex.substring(4, 6), 16);
  }

  return { r, g, b };
}

// Convert RGB to HEX string
export function rgbToHex(r: number, g: number, b: number): string {
  const toHex = (c: number) => {
    const hex = Math.max(0, Math.min(255, Math.round(c))).toString(16);
    return hex.length === 1 ? '0' : '' + hex;
  };
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

// Convert RGB to HSL
export function rgbToHsl(r: number, g: number, b: number): { h: number; s: number; l: number } {
  r /= 255;
  g /= 255;
  b /= 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }

  return {
    h: Math.round(h * 360),
    s: Math.round(s * 100),
    l: Math.round(l * 100),
  };
}

// Convert HSL to RGB
export function hslToRgb(h: number, s: number, l: number): { r: number; g: number; b: number } {
  h /= 360;
  s /= 100;
  l /= 100;

  let r = l;
  let g = l;
  let b = l;

  if (s !== 0) {
    const hue2rgb = (p: number, q: number, t: number) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;

    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }

  return {
    r: Math.round(r * 255),
    g: Math.round(g * 255),
    b: Math.round(b * 255),
  };
}

// Convert HEX to HSL
export function hexToHsl(hex: string): { h: number; s: number; l: number } {
  const rgb = hexToRgb(hex) || { r: 255, g: 0, b: 0 };
  return rgbToHsl(rgb.r, rgb.g, rgb.b);
}

// Convert HSL to HEX
export function hslToHex(h: number, s: number, l: number): string {
  const rgb = hslToRgb(h, s, l);
  return rgbToHex(rgb.r, rgb.g, rgb.b);
}

// Format a single color stop into CSS representation, accounting for opacity
export function formatStopToCss(stop: GradientStop): string {
  const rgb = hexToRgb(stop.color);
  const opacityVal = stop.opacity / 100;

  if (rgb && opacityVal < 1) {
    return `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${opacityVal.toFixed(2)}) ${stop.position}%`;
  }
  return `${stop.color} ${stop.position}%`;
}

// Build the full CSS background-image value
export function getGradientCss(config: GradientConfig): string {
  // Sort stops by position to guarantee proper rendering sequence in CSS
  const sortedStops = [...config.stops].sort((a, b) => a.position - b.position);
  const stopStrings = sortedStops.map(formatStopToCss);

  const prefix = config.repeating ? 'repeating-' : '';

  switch (config.type) {
    case 'linear':
      return `${prefix}linear-gradient(${config.angle}deg, ${stopStrings.join(', ')})`;
    case 'radial':
      return `${prefix}radial-gradient(${config.shape} at ${config.positionX}% ${config.positionY}%, ${stopStrings.join(', ')})`;
    case 'conic':
      // Conic gradient doesn't use shape, but uses starting angle and center position
      return `${prefix}conic-gradient(from ${config.angle}deg at ${config.positionX}% ${config.positionY}%, ${stopStrings.join(', ')})`;
    default:
      return '';
  }
}

// Generate tailwind-friendly arbitrary value string
export function getTailwindClass(config: GradientConfig): string {
  const css = getGradientCss(config);
  // Remove whitespace inside the CSS to fit arbitrary value formatting in Tailwind: bg-[...]
  const condensedCss = css.replace(/\s+/g, '');
  return `bg-[${condensedCss}]`;
}
