export type GradientType = 'linear' | 'radial' | 'conic';

export interface GradientStop {
  id: string;
  color: string; // HEX color, e.g. #ff0000
  position: number; // 0 to 100
  opacity: number; // 0 to 100 (percentage)
}

export type RadialShape = 'circle' | 'ellipse';

export interface GradientPreset {
  name: string;
  type: GradientType;
  angle: number;
  shape?: RadialShape;
  positionX?: number; // 0 to 100
  positionY?: number; // 0 to 100
  stops: Omit<GradientStop, 'id'>[];
}

export interface GradientConfig {
  type: GradientType;
  angle: number; // 0 to 360
  shape: RadialShape;
  positionX: number; // 0-100
  positionY: number; // 0-100
  stops: GradientStop[];
  repeating: boolean;
}
