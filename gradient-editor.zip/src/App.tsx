import React, { useState, useEffect, useRef } from 'react';
import { 
  Copy, 
  Download, 
  RotateCcw, 
  Undo2, 
  Redo2, 
  Maximize2, 
  CreditCard, 
  Smartphone, 
  Layout, 
  Repeat, 
  Layers, 
  Code, 
  Check, 
  Palette, 
  Target, 
  Sliders,
  HelpCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { GradientConfig, GradientStop, GradientPreset, RadialShape } from './types';
import { getGradientCss, getTailwindClass, hexToRgb, hslToHex } from './utils/colorUtils';
import { ColorPicker } from './components/ColorPicker';
import { GradientSlider } from './components/GradientSlider';
import { AnglePicker } from './components/AnglePicker';
import { Presets, PRESETS_LIST } from './components/Presets';

// Initial state: a gorgeous warm sunset gradient
const INITIAL_STOPS: GradientStop[] = [
  { id: 'stop-1', color: '#ff7e5f', position: 0, opacity: 100 },
  { id: 'stop-2', color: '#feb47b', position: 100, opacity: 100 }
];

const INITIAL_CONFIG: GradientConfig = {
  type: 'linear',
  angle: 135,
  shape: 'circle',
  positionX: 50,
  positionY: 50,
  stops: INITIAL_STOPS,
  repeating: false
};

type MockupType = 'full' | 'card' | 'phone' | 'landing';
type ExportTab = 'css' | 'tailwind' | 'svg' | 'info';

export default function App() {
  const [config, setConfig] = useState<GradientConfig>(INITIAL_CONFIG);
  const [selectedStopId, setSelectedStopId] = useState<string | null>('stop-1');
  const [mockup, setMockup] = useState<MockupType>('full');
  const [exportTab, setExportTab] = useState<ExportTab>('css');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  
  // History tracking for Undo/Redo (supports up to 30 actions)
  const [history, setHistory] = useState<GradientConfig[]>([INITIAL_CONFIG]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const previewContainerRef = useRef<HTMLDivElement>(null);

  // Synchronize first selected stop if none is set
  useEffect(() => {
    if (config.stops.length > 0 && !selectedStopId) {
      setSelectedStopId(config.stops[0].id);
    }
  }, [config.stops, selectedStopId]);

  // Push to history helper
  const saveHistory = (newConfig?: GradientConfig) => {
    const targetConfig = newConfig || config;
    setHistory(prev => {
      // Erase any "Redo" paths if we perform a new action
      const next = prev.slice(0, historyIndex + 1);
      next.push(JSON.parse(JSON.stringify(targetConfig))); // deep copy
      if (next.length > 30) next.shift(); // limit to 30 steps
      return next;
    });
    setHistoryIndex(prev => Math.min(29, prev + 1));
  };

  // Trigger Undo
  const handleUndo = () => {
    if (historyIndex > 0) {
      const prevIndex = historyIndex - 1;
      setHistoryIndex(prevIndex);
      setConfig(JSON.parse(JSON.stringify(history[prevIndex])));
      showToast('Deshecho');
    }
  };

  // Trigger Redo
  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const nextIndex = historyIndex + 1;
      setHistoryIndex(nextIndex);
      setConfig(JSON.parse(JSON.stringify(history[nextIndex])));
      showToast('Rehecho');
    }
  };

  // Helper to show a temporary Toast message
  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  // Copy text to clipboard and show toast feedback
  const handleCopyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast('¡Copiado al portapapeles!');
  };

  // Reset workspace
  const handleReset = () => {
    setConfig(INITIAL_CONFIG);
    setSelectedStopId('stop-1');
    setHistory([INITIAL_CONFIG]);
    setHistoryIndex(0);
    showToast('Restaurado a valores iniciales');
  };

  // Select a preset
  const handleSelectPreset = (preset: GradientPreset) => {
    const formattedStops = preset.stops.map((stop, idx) => ({
      id: `preset-stop-${idx}-${Date.now()}`,
      ...stop
    })) as GradientStop[];

    const newConfig: GradientConfig = {
      type: preset.type,
      angle: preset.angle,
      shape: preset.shape || 'circle',
      positionX: preset.positionX !== undefined ? preset.positionX : 50,
      positionY: preset.positionY !== undefined ? preset.positionY : 50,
      stops: formattedStops,
      repeating: false
    };

    setConfig(newConfig);
    setSelectedStopId(formattedStops[0].id);
    saveHistory(newConfig);
  };

  // Generate scientific random harmonized gradient
  const handleRandomize = () => {
    const numStops = Math.floor(Math.random() * 2) + 2; // 2 or 3 stops
    const baseHue = Math.floor(Math.random() * 360);
    
    // Choose color harmony
    const harmonyPattern = Math.random();
    const generatedStops: GradientStop[] = [];

    for (let i = 0; i < numStops; i++) {
      let stopHue = baseHue;
      if (i > 0) {
        if (harmonyPattern < 0.35) {
          // Analogous color scheme (smooth shifts)
          stopHue = (baseHue + (i * 35)) % 360;
        } else if (harmonyPattern < 0.7) {
          // Split-complementary / Triadic (vibrant contrast)
          stopHue = (baseHue + (i * 120)) % 360;
        } else {
          // Soft pastel shifts
          stopHue = (baseHue + (i * 150)) % 360;
        }
      }
      
      const saturation = Math.floor(Math.random() * 20) + 75; // 75% to 95%
      const lightness = Math.floor(Math.random() * 15) + 45; // 45% to 60%
      const color = hslToHex(stopHue, saturation, lightness);
      
      // Distribute positions equally
      const position = i === 0 ? 0 : i === numStops - 1 ? 100 : Math.floor((100 / (numStops - 1)) * i);
      
      generatedStops.push({
        id: `rand-stop-${i}-${Date.now()}`,
        color,
        position,
        opacity: 100
      });
    }

    const types: ('linear' | 'radial' | 'conic')[] = ['linear', 'radial'];
    const randomType = types[Math.floor(Math.random() * types.length)];
    const randomAngle = Math.floor(Math.random() * 8) * 45; // multiples of 45

    const newConfig: GradientConfig = {
      type: randomType,
      angle: randomAngle,
      shape: 'circle',
      positionX: 50,
      positionY: 50,
      stops: generatedStops,
      repeating: false
    };

    setConfig(newConfig);
    setSelectedStopId(generatedStops[0].id);
    saveHistory(newConfig);
  };

  // Add a stop
  const handleAddStop = (position: number) => {
    // Determine color by duplicating the closest stop's color
    const closestStop = config.stops.reduce((prev, curr) => 
      Math.abs(curr.position - position) < Math.abs(prev.position - position) ? curr : prev
    );

    const newStop: GradientStop = {
      id: `stop-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      color: closestStop.color,
      position,
      opacity: closestStop.opacity
    };

    const updatedStops = [...config.stops, newStop];
    const newConfig = { ...config, stops: updatedStops };
    
    setConfig(newConfig);
    setSelectedStopId(newStop.id);
    saveHistory(newConfig);
  };

  // Update stop position
  const handleUpdateStopPosition = (id: string, position: number) => {
    const updatedStops = config.stops.map(stop => 
      stop.id === id ? { ...stop, position } : stop
    );
    setConfig(prev => ({ ...prev, stops: updatedStops }));
    // Do not save to history continuously during active drag - we handle it on pointer release or discrete actions if preferred.
    // To make history perfectly robust, we can periodically debounced save, or save on manual adjustments.
  };

  // Update stop color
  const handleUpdateStopColor = (hex: string) => {
    if (!selectedStopId) return;
    const updatedStops = config.stops.map(stop => 
      stop.id === selectedStopId ? { ...stop, color: hex } : stop
    );
    const newConfig = { ...config, stops: updatedStops };
    setConfig(newConfig);
  };

  // Update stop opacity
  const handleUpdateStopOpacity = (opacity: number) => {
    if (!selectedStopId) return;
    const updatedStops = config.stops.map(stop => 
      stop.id === selectedStopId ? { ...stop, opacity } : stop
    );
    const newConfig = { ...config, stops: updatedStops };
    setConfig(newConfig);
  };

  // Complete edit of color/opacity (triggered when they finish dragging sliders, to register in Undo/Redo)
  const handleFinishedEditingColor = () => {
    saveHistory();
  };

  // Remove a stop (must keep at least 2)
  const handleRemoveStop = (id: string) => {
    if (config.stops.length <= 2) return;
    const updatedStops = config.stops.filter(stop => stop.id !== id);
    const remainingSelected = selectedStopId === id ? updatedStops[0].id : selectedStopId;
    
    const newConfig = { ...config, stops: updatedStops };
    setConfig(newConfig);
    setSelectedStopId(remainingSelected);
    saveHistory(newConfig);
  };

  // Draggable Focal Point dragging handler on preview container
  const handleFocalDragStart = (startEvent: React.MouseEvent | React.TouchEvent) => {
    startEvent.stopPropagation();
    
    const handleMove = (moveEvent: MouseEvent | TouchEvent) => {
      if (!previewContainerRef.current) return;
      const rect = previewContainerRef.current.getBoundingClientRect();
      
      let clientX = 0;
      let clientY = 0;
      if ('touches' in moveEvent) {
        if (moveEvent.touches.length === 0) return;
        clientX = moveEvent.touches[0].clientX;
        clientY = moveEvent.touches[0].clientY;
      } else {
        clientX = moveEvent.clientX;
        clientY = moveEvent.clientY;
      }

      const x = Math.max(0, Math.min(100, Math.round(((clientX - rect.left) / rect.width) * 100)));
      const y = Math.max(0, Math.min(100, Math.round(((clientY - rect.top) / rect.height) * 100)));
      
      setConfig(prev => ({
        ...prev,
        positionX: x,
        positionY: y
      }));
    };

    const handleEnd = () => {
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleEnd);
      document.removeEventListener('touchmove', handleMove);
      document.removeEventListener('touchend', handleEnd);
      saveHistory();
    };

    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleEnd);
    document.addEventListener('touchmove', handleMove, { passive: true });
    document.addEventListener('touchend', handleEnd);
  };

  // Download High Definition PNG (1920x1080)
  const handleDownloadPng = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1920;
    canvas.height = 1080;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const sortedStops = [...config.stops].sort((a, b) => a.position - b.position);
    let gradient: CanvasGradient;

    if (config.type === 'linear') {
      const r = Math.sqrt(canvas.width ** 2 + canvas.height ** 2) / 2;
      const rad = ((config.angle - 90) * Math.PI) / 180;
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const x0 = cx - r * Math.cos(rad);
      const y0 = cy - r * Math.sin(rad);
      const x1 = cx + r * Math.cos(rad);
      const y1 = cy + r * Math.sin(rad);
      gradient = ctx.createLinearGradient(x0, y0, x1, y1);
    } else if (config.type === 'radial') {
      const cx = (config.positionX / 100) * canvas.width;
      const cy = (config.positionY / 100) * canvas.height;
      const r = Math.max(canvas.width, canvas.height) / 2;
      gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
    } else {
      const cx = (config.positionX / 100) * canvas.width;
      const cy = (config.positionY / 100) * canvas.height;
      const startAngle = (config.angle * Math.PI) / 180;
      if (typeof ctx.createConicGradient === 'function') {
        gradient = ctx.createConicGradient(startAngle, cx, cy);
      } else {
        gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, canvas.width / 2);
      }
    }

    sortedStops.forEach(stop => {
      const rgb = hexToRgb(stop.color) || { r: 0, g: 0, b: 0 };
      gradient.addColorStop(stop.position / 100, `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${stop.opacity / 100})`);
    });

    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const link = document.createElement('a');
    link.download = `gradient-${config.type}-${new Date().getTime()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
    showToast('¡Descarga iniciada! (1920x1080px)');
  };

  // Generate SVG code string
  const generateSvgCode = () => {
    const sortedStops = [...config.stops].sort((a, b) => a.position - b.position);
    let gradDef = '';
    
    if (config.type === 'linear') {
      const angleRad = (config.angle * Math.PI) / 180;
      const x1 = Math.round(50 - 50 * Math.sin(angleRad));
      const y1 = Math.round(50 + 50 * Math.cos(angleRad));
      const x2 = Math.round(50 + 50 * Math.sin(angleRad));
      const y2 = Math.round(50 - 50 * Math.cos(angleRad));
      gradDef = `<linearGradient id="gradient" x1="${x1}%" y1="${y1}%" x2="${x2}%" y2="${y2}%">\n`;
    } else if (config.type === 'radial') {
      gradDef = `<radialGradient id="gradient" cx="${config.positionX}%" cy="${config.positionY}%" r="50%">\n`;
    } else {
      // Conic gradients do not have a native standard SVG representation. We output a fallback.
      return `<!-- Nota: Los gradientes cónicos no son soportados de forma nativa por el estándar SVG simple. -->
<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
  <rect width="100%" height="100%" fill="${sortedStops[0].color}" />
</svg>`;
    }

    sortedStops.forEach(stop => {
      const opacityVal = stop.opacity / 100;
      gradDef += `    <stop offset="${stop.position}%" stop-color="${stop.color}" stop-opacity="${opacityVal}" />\n`;
    });
    gradDef += `  </linearGradient>`;

    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100%" height="100%">
  <defs>
    ${gradDef}
  </defs>
  <rect width="100%" height="100%" fill="url(#gradient)" />
</svg>`;
  };

  const gradientString = getGradientCss(config);
  const tailwindString = getTailwindClass(config);
  const selectedStop = config.stops.find(s => s.id === selectedStopId);

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans antialiased pb-12 selection:bg-zinc-900 selection:text-white">
      
      {/* Decorative ambient background blur */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-zinc-200 rounded-full blur-3xl opacity-40 pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-zinc-100 rounded-full blur-3xl opacity-40 pointer-events-none" />

      {/* Main Workspace Header */}
      <header className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-6 border-b border-zinc-200/60">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-[10px] font-mono tracking-wider font-semibold uppercase bg-zinc-900 text-white rounded-full">
                Herramienta de diseño
              </span>
              <span className="text-xs font-mono text-zinc-400">v1.0</span>
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-zinc-900 mt-1">
              Gradient Studio
            </h1>
            <p className="text-sm text-zinc-500 mt-0.5">
              Crea, personaliza y exporta fondos degradados interactivos de alta calidad.
            </p>
          </div>

          {/* Core App Actions (Undo, Redo, Reset) */}
          <div className="flex items-center gap-2 bg-white border border-zinc-200 shadow-sm rounded-xl p-1 shrink-0">
            <button
              id="header-undo"
              type="button"
              onClick={handleUndo}
              disabled={historyIndex === 0}
              className={`p-2 rounded-lg transition-colors ${
                historyIndex > 0
                  ? 'text-zinc-700 hover:bg-zinc-50 active:scale-95'
                  : 'text-zinc-300 cursor-not-allowed'
              }`}
              title="Deshacer (Ctrl+Z)"
            >
              <Undo2 className="w-4 h-4" />
            </button>
            <button
              id="header-redo"
              type="button"
              onClick={handleRedo}
              disabled={historyIndex === history.length - 1}
              className={`p-2 rounded-lg transition-colors ${
                historyIndex < history.length - 1
                  ? 'text-zinc-700 hover:bg-zinc-50 active:scale-95'
                  : 'text-zinc-300 cursor-not-allowed'
              }`}
              title="Rehacer (Ctrl+Y)"
            >
              <Redo2 className="w-4 h-4" />
            </button>
            <div className="w-px h-5 bg-zinc-200" />
            <button
              id="header-reset"
              type="button"
              onClick={handleReset}
              className="p-2 text-zinc-500 hover:text-red-600 hover:bg-red-50 rounded-lg active:scale-95 transition-all"
              title="Restaurar parámetros originales"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Workspace Grid Layout */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Interactive Previews & Export Center */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          
          {/* Preview Canvas with Mockups Switcher */}
          <div className="bg-white border border-zinc-200 rounded-2xl p-4 shadow-sm relative overflow-hidden flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <span className="text-xs font-mono font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5">
                <Maximize2 className="w-3.5 h-3.5" /> Previsualización en Tiempo Real
              </span>

              {/* Viewport/Mockups buttons */}
              <div className="flex gap-1 bg-zinc-100 p-1 rounded-lg border border-zinc-200/50">
                <button
                  id="mockup-btn-full"
                  type="button"
                  onClick={() => setMockup('full')}
                  className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                    mockup === 'full' 
                      ? 'bg-white text-zinc-950 shadow-sm' 
                      : 'text-zinc-500 hover:text-zinc-900'
                  }`}
                >
                  <Maximize2 className="w-3 h-3" />
                  <span className="hidden sm:inline">Completo</span>
                </button>
                <button
                  id="mockup-btn-card"
                  type="button"
                  onClick={() => setMockup('card')}
                  className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                    mockup === 'card' 
                      ? 'bg-white text-zinc-950 shadow-sm' 
                      : 'text-zinc-500 hover:text-zinc-900'
                  }`}
                >
                  <CreditCard className="w-3 h-3" />
                  <span className="hidden sm:inline">Tarjeta</span>
                </button>
                <button
                  id="mockup-btn-phone"
                  type="button"
                  onClick={() => setMockup('phone')}
                  className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                    mockup === 'phone' 
                      ? 'bg-white text-zinc-950 shadow-sm' 
                      : 'text-zinc-500 hover:text-zinc-900'
                  }`}
                >
                  <Smartphone className="w-3 h-3" />
                  <span className="hidden sm:inline">Móvil</span>
                </button>
                <button
                  id="mockup-btn-landing"
                  type="button"
                  onClick={() => setMockup('landing')}
                  className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                    mockup === 'landing' 
                      ? 'bg-white text-zinc-950 shadow-sm' 
                      : 'text-zinc-500 hover:text-zinc-900'
                  }`}
                >
                  <Layout className="w-3 h-3" />
                  <span className="hidden sm:inline">Landing</span>
                </button>
              </div>
            </div>

            {/* Preview Frame Container */}
            <div 
              id="preview-viewport-box"
              className="relative aspect-video w-full rounded-xl bg-zinc-100 border border-zinc-200/60 overflow-hidden flex items-center justify-center shadow-inner select-none"
              style={{
                backgroundImage: 'conic-gradient(#ccc 0.25turn, transparent 0.25turn 0.5turn, #ccc 0.5turn 0.75turn, transparent 0.75turn)',
                backgroundSize: '16px 16px',
                backgroundPosition: '0 0'
              }}
            >
              {/* Full view mode */}
              {mockup === 'full' && (
                <div 
                  ref={previewContainerRef}
                  className="absolute inset-0 w-full h-full"
                  style={{ background: gradientString }}
                >
                  {/* Draggable crosshair overlay for radial/conic gradients focal center */}
                  {(config.type === 'radial' || config.type === 'conic') && (
                    <div 
                      id="radial-conic-target-node"
                      className="absolute w-8 h-8 -ml-4 -mt-4 rounded-full border-2 border-white bg-black/20 backdrop-blur-xs flex items-center justify-center cursor-move shadow-md group animate-pulse hover:scale-110 active:scale-95 transition-transform"
                      style={{ left: `${config.positionX}%`, top: `${config.positionY}%` }}
                      onMouseDown={handleFocalDragStart}
                      onTouchStart={handleFocalDragStart}
                      title="Arrastra para mover el centro del degradado"
                    >
                      <Target className="w-4 h-4 text-white" />
                      <div className="absolute top-10 left-1/2 -translate-x-1/2 bg-zinc-900/90 text-[9px] text-white px-1.5 py-0.5 rounded font-mono shadow opacity-0 group-hover:opacity-100 transition-opacity">
                        X:{config.positionX}% Y:{config.positionY}%
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Card visualization mode */}
              {mockup === 'card' && (
                <div className="absolute inset-0 w-full h-full bg-zinc-950 flex items-center justify-center p-6">
                  {/* Background ambient light */}
                  <div 
                    className="absolute inset-0 opacity-40 blur-xl scale-75"
                    style={{ background: gradientString }}
                  />
                  {/* Floating Glassmorphic Credit Card */}
                  <div className="relative w-80 h-48 rounded-2xl border border-white/20 bg-white/10 backdrop-blur-md p-6 flex flex-col justify-between shadow-2xl text-white select-none">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="block text-[10px] font-mono text-zinc-300 uppercase tracking-widest leading-none">
                          Focal Premium Card
                        </span>
                        <span className="block text-sm font-semibold tracking-wide mt-1">
                          AURA BLACK
                        </span>
                      </div>
                      <div className="w-8 h-8 rounded-lg overflow-hidden bg-white/10 flex items-center justify-center border border-white/10">
                        <div 
                          className="w-full h-full"
                          style={{ background: gradientString }}
                        />
                      </div>
                    </div>

                    {/* Simulating microchip */}
                    <div className="w-10 h-8 bg-amber-200/85 rounded-md border border-amber-300/30 flex items-center justify-center p-1.5 self-start">
                      <div className="grid grid-cols-3 gap-[1px] w-full h-full border border-black/10 rounded-xs" />
                    </div>

                    <div>
                      <div className="text-lg font-mono tracking-widest text-zinc-100">
                        •••• •••• •••• 2026
                      </div>
                      <div className="flex justify-between items-center text-[10px] font-mono text-zinc-300 mt-2">
                        <span>LIFECKILLZ DIGITAL</span>
                        <span>07 / 26</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* iPhone visualization mode */}
              {mockup === 'phone' && (
                <div className="absolute inset-0 w-full h-full bg-zinc-900 flex items-center justify-center py-4">
                  {/* Phone frame bezel */}
                  <div className="relative h-[250px] w-[120px] sm:h-[300px] sm:w-[145px] rounded-[32px] border-4 border-zinc-800 bg-black shadow-2xl overflow-hidden flex flex-col">
                    {/* Speaker/Camera notch */}
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-3.5 bg-black rounded-b-xl z-50 flex items-center justify-center">
                      <div className="w-5 h-[2px] bg-zinc-800 rounded-full mb-1" />
                    </div>

                    {/* Screen content (Gradient wallpaper) */}
                    <div 
                      className="absolute inset-0 w-full h-full flex flex-col justify-between p-4"
                      style={{ background: gradientString }}
                    >
                      {/* Top status bar */}
                      <div className="flex justify-between items-center text-[8px] font-semibold text-white/90 z-10">
                        <span>09:41</span>
                        <div className="flex items-center gap-1 scale-90">
                          <span>5G</span>
                          <div className="w-3.5 h-1.5 border border-white/80 rounded-xs p-[1px] flex items-center">
                            <div className="w-2.5 h-full bg-white rounded-2xs" />
                          </div>
                        </div>
                      </div>

                      {/* Dynamic clock lock-screen */}
                      <div className="text-center mt-3 z-10 text-white select-none">
                        <span className="block text-2xl font-bold tracking-tight leading-none text-white/90">
                          09:41
                        </span>
                        <span className="block text-[8px] font-medium tracking-wide mt-0.5 text-white/70">
                          SÁBADO, 4 DE JULIO
                        </span>
                      </div>

                      {/* Lockscreen utility icons */}
                      <div className="flex justify-between items-center z-10 px-2">
                        <div className="w-6 h-6 rounded-full bg-black/20 backdrop-blur-xs flex items-center justify-center text-white text-[10px]">
                          🔦
                        </div>
                        <div className="w-6 h-6 rounded-full bg-black/20 backdrop-blur-xs flex items-center justify-center text-white text-[10px]">
                          📷
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Landing Page visualization mode */}
              {mockup === 'landing' && (
                <div className="absolute inset-0 w-full h-full bg-white flex flex-col">
                  {/* Mock Navbar */}
                  <div className="px-6 py-2.5 border-b border-zinc-100 flex justify-between items-center bg-white shrink-0">
                    <span className="text-xs font-extrabold tracking-wider text-zinc-900">
                      GRADIENT
                    </span>
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] text-zinc-500 font-medium hover:text-zinc-950 cursor-pointer">Inicio</span>
                      <span className="text-[10px] text-zinc-500 font-medium hover:text-zinc-950 cursor-pointer">Precios</span>
                      <button type="button" className="px-2.5 py-1 text-[9px] font-bold text-white bg-zinc-900 rounded-md">
                        Comenzar
                      </button>
                    </div>
                  </div>

                  {/* Hero Container */}
                  <div 
                    className="flex-1 flex flex-col justify-center items-center text-center p-6"
                    style={{ background: gradientString }}
                  >
                    {/* Hero text overlay */}
                    <div className="max-w-md bg-white/75 backdrop-blur-md p-4 sm:p-5 rounded-2xl border border-white/40 shadow-lg">
                      <span className="px-2 py-0.5 text-[8px] font-extrabold bg-zinc-900 text-white rounded-full uppercase">
                        Novedad
                      </span>
                      <h2 className="text-base sm:text-lg font-black tracking-tight text-zinc-900 mt-2 leading-tight">
                        Crea experiencias visuales sublimes
                      </h2>
                      <p className="text-[10px] sm:text-xs text-zinc-600 mt-1.5 leading-relaxed">
                        Herramienta de diseño inteligente de fondos y recursos para tu próximo proyecto web o interfaz.
                      </p>
                      
                      <div className="flex justify-center gap-2 mt-3.5">
                        <button type="button" className="px-3.5 py-1.5 text-[9px] font-bold text-white bg-zinc-950 rounded-lg hover:scale-103 transition-transform shadow">
                          Saber más
                        </button>
                        <button type="button" className="px-3.5 py-1.5 text-[9px] font-bold text-zinc-800 bg-white border border-zinc-200 rounded-lg hover:scale-103 transition-transform">
                          Prueba libre
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Code Export Center / Tabbed panel */}
          <div className="bg-white border border-zinc-200 rounded-2xl shadow-sm overflow-hidden flex flex-col flex-1 min-h-[280px]">
            {/* Header Tabs */}
            <div className="border-b border-zinc-200/60 bg-zinc-50/50 flex justify-between items-center px-4">
              <div className="flex">
                <button
                  id="tab-btn-css"
                  type="button"
                  onClick={() => setExportTab('css')}
                  className={`px-4 py-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
                    exportTab === 'css'
                      ? 'border-zinc-950 text-zinc-950'
                      : 'border-transparent text-zinc-500 hover:text-zinc-800'
                  }`}
                >
                  <Code className="w-3.5 h-3.5" />
                  <span>Código CSS</span>
                </button>
                <button
                  id="tab-btn-tailwind"
                  type="button"
                  onClick={() => setExportTab('tailwind')}
                  className={`px-4 py-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
                    exportTab === 'tailwind'
                      ? 'border-zinc-950 text-zinc-950'
                      : 'border-transparent text-zinc-500 hover:text-zinc-800'
                  }`}
                >
                  <Palette className="w-3.5 h-3.5" />
                  <span>Tailwind</span>
                </button>
                <button
                  id="tab-btn-svg"
                  type="button"
                  onClick={() => setExportTab('svg')}
                  className={`px-4 py-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
                    exportTab === 'svg'
                      ? 'border-zinc-950 text-zinc-950'
                      : 'border-transparent text-zinc-500 hover:text-zinc-800'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Vector SVG</span>
                </button>
                <button
                  id="tab-btn-info"
                  type="button"
                  onClick={() => setExportTab('info')}
                  className={`px-4 py-3 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
                    exportTab === 'info'
                      ? 'border-zinc-950 text-zinc-950'
                      : 'border-transparent text-zinc-500 hover:text-zinc-800'
                  }`}
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Ayuda</span>
                </button>
              </div>

              {/* Download PNG High Definition */}
              <button
                id="btn-download-png"
                type="button"
                onClick={handleDownloadPng}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 text-white hover:bg-zinc-800 active:scale-95 text-xs font-bold rounded-lg transition-all shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                <span>PNG</span>
              </button>
            </div>

            {/* Tab contents */}
            <div className="p-4 flex-1 flex flex-col bg-white">
              {exportTab === 'css' && (
                <div className="flex-1 flex flex-col gap-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[11px] font-mono text-zinc-400">CSS standard styling rule</span>
                    <button
                      id="copy-css-btn"
                      type="button"
                      onClick={() => handleCopyToClipboard(`background: ${gradientString};`)}
                      className="flex items-center gap-1 text-[11px] font-medium text-zinc-500 hover:text-zinc-900 bg-zinc-100 hover:bg-zinc-200 px-2 py-1 rounded transition-colors"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Copiar</span>
                    </button>
                  </div>
                  <pre className="p-3.5 bg-zinc-950 text-zinc-200 font-mono text-xs rounded-xl overflow-x-auto flex-1 whitespace-pre-wrap select-all leading-relaxed shadow-inner">
                    <span className="text-pink-400">background</span>: <span className="text-indigo-300">{gradientString}</span>;
                  </pre>
                </div>
              )}

              {exportTab === 'tailwind' && (
                <div className="flex-1 flex flex-col gap-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[11px] font-mono text-zinc-400">Tailwind arbitrary background class</span>
                    <button
                      id="copy-tailwind-btn"
                      type="button"
                      onClick={() => handleCopyToClipboard(tailwindString)}
                      className="flex items-center gap-1 text-[11px] font-medium text-zinc-500 hover:text-zinc-900 bg-zinc-100 hover:bg-zinc-200 px-2 py-1 rounded transition-colors"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Copiar</span>
                    </button>
                  </div>
                  <pre className="p-3.5 bg-zinc-950 text-zinc-200 font-mono text-xs rounded-xl overflow-x-auto flex-1 whitespace-pre-wrap select-all leading-relaxed shadow-inner">
                    <span className="text-amber-400">className</span>=<span className="text-emerald-300">"{tailwindString}"</span>
                  </pre>
                </div>
              )}

              {exportTab === 'svg' && (
                <div className="flex-1 flex flex-col gap-3">
                  <div className="flex justify-between items-center">
                    <span className="text-[11px] font-mono text-zinc-400">Vector SVG standard container code</span>
                    <button
                      id="copy-svg-btn"
                      type="button"
                      onClick={() => handleCopyToClipboard(generateSvgCode())}
                      className="flex items-center gap-1 text-[11px] font-medium text-zinc-500 hover:text-zinc-900 bg-zinc-100 hover:bg-zinc-200 px-2 py-1 rounded transition-colors"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Copiar</span>
                    </button>
                  </div>
                  <pre className="p-3.5 bg-zinc-950 text-zinc-200 font-mono text-xs rounded-xl overflow-x-auto flex-1 whitespace-pre-wrap select-all leading-relaxed max-h-[160px] shadow-inner">
                    {generateSvgCode()}
                  </pre>
                </div>
              )}

              {exportTab === 'info' && (
                <div className="flex-1 text-sm text-zinc-600 leading-relaxed space-y-3.5">
                  <p>
                    <strong>¿Cómo usar el Editor?</strong>
                  </p>
                  <ul className="list-disc pl-5 space-y-2 text-xs">
                    <li>
                      <strong>Editar puntos de color:</strong> Selecciona un punto en la barra y cámbiale el color, posición u opacidad en el panel de control.
                    </li>
                    <li>
                      <strong>Añadir puntos:</strong> Haz clic en cualquier parte vacía del carril del degradado para insertar un nuevo punto con el mismo tono.
                    </li>
                    <li>
                      <strong>Arrastrar puntos:</strong> Sostén y desliza de forma horizontal cualquier burbuja de color en el carril.
                    </li>
                    <li>
                      <strong>Desplazar Foco (Radial/Cónico):</strong> Activa el tipo radial o cónico y arrastra directamente el nodo de mira en la vista previa para cambiar las coordenadas de inicio.
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Configuration & Styling controls */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          
          {/* Section 1: Geometry & Basic Setup */}
          <div className="bg-white border border-zinc-200 rounded-2xl p-5 shadow-sm space-y-5">
            <h2 className="text-xs font-mono font-bold tracking-wider uppercase text-zinc-400 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5" /> Geometría & Tipo
            </h2>

            {/* Gradient Type Selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-600 block">Tipo de degradado</label>
              <div className="grid grid-cols-3 gap-2">
                {(['linear', 'radial', 'conic'] as const).map((t) => (
                  <button
                    id={`type-btn-${t}`}
                    key={t}
                    type="button"
                    onClick={() => {
                      const newConfig = { ...config, type: t };
                      setConfig(newConfig);
                      saveHistory(newConfig);
                    }}
                    className={`py-2 px-3 text-xs font-bold rounded-xl border flex flex-col items-center gap-1.5 transition-all ${
                      config.type === t
                        ? 'bg-zinc-950 text-white border-zinc-950 shadow-sm'
                        : 'bg-white text-zinc-600 border-zinc-200 hover:bg-zinc-50 hover:text-zinc-900'
                    }`}
                  >
                    <span className="capitalize">{t === 'linear' ? 'Lineal' : t === 'radial' ? 'Radial' : 'Cónico'}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Repeating Pattern Switch */}
            <div className="flex justify-between items-center py-1.5 border-t border-zinc-100">
              <div className="flex items-center gap-2">
                <Repeat className="w-4 h-4 text-zinc-400" />
                <div>
                  <span className="block text-xs font-semibold text-zinc-700">Patrón repetitivo</span>
                  <span className="block text-[10px] text-zinc-400">Repite el ciclo del degradado</span>
                </div>
              </div>
              <button
                id="repeating-toggle-btn"
                type="button"
                onClick={() => {
                  const newConfig = { ...config, repeating: !config.repeating };
                  setConfig(newConfig);
                  saveHistory(newConfig);
                }}
                className={`w-11 h-6 rounded-full transition-colors flex items-center p-1 ${
                  config.repeating ? 'bg-zinc-950 justify-end' : 'bg-zinc-200 justify-start'
                }`}
              >
                <div className="w-4 h-4 rounded-full bg-white shadow-sm" />
              </button>
            </div>

            {/* Direction details conditionally */}
            <div className="border-t border-zinc-100 pt-4">
              {config.type === 'linear' && (
                <AnglePicker 
                  angle={config.angle} 
                  onChangeAngle={(angle) => {
                    setConfig(prev => ({ ...prev, angle }));
                  }} 
                />
              )}

              {(config.type === 'radial' || config.type === 'conic') && (
                <div className="space-y-4">
                  {/* If Radial, show shape selector */}
                  {config.type === 'radial' && (
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-zinc-600 block">Forma radial</label>
                      <div className="grid grid-cols-2 gap-2">
                        {(['circle', 'ellipse'] as const).map((s) => (
                          <button
                            id={`shape-btn-${s}`}
                            key={s}
                            type="button"
                            onClick={() => {
                              const newConfig = { ...config, shape: s };
                              setConfig(newConfig);
                              saveHistory(newConfig);
                            }}
                            className={`py-1.5 px-3 text-xs font-semibold rounded-lg border transition-colors ${
                              config.shape === s
                                ? 'bg-zinc-950 text-white border-zinc-950'
                                : 'bg-white text-zinc-600 border-zinc-200 hover:bg-zinc-50'
                            }`}
                          >
                            {s === 'circle' ? 'Círculo' : 'Elipse'}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* If Conic, show starting angle */}
                  {config.type === 'conic' && (
                    <AnglePicker 
                      angle={config.angle} 
                      onChangeAngle={(angle) => {
                        setConfig(prev => ({ ...prev, angle }));
                      }} 
                    />
                  )}

                  {/* X and Y Focal positions coordinates */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-xs font-mono text-zinc-500">
                        <span>Origen X</span>
                        <span>{config.positionX}%</span>
                      </div>
                      <input
                        id="radial-origin-x-slider"
                        type="range"
                        min="0"
                        max="100"
                        value={config.positionX}
                        onChange={(e) => {
                          setConfig(prev => ({ ...prev, positionX: parseInt(e.target.value) }));
                        }}
                        onMouseUp={() => saveHistory()}
                        onTouchEnd={() => saveHistory()}
                        className="w-full h-1 bg-zinc-200 rounded-lg appearance-none cursor-pointer accent-zinc-950"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-xs font-mono text-zinc-500">
                        <span>Origen Y</span>
                        <span>{config.positionY}%</span>
                      </div>
                      <input
                        id="radial-origin-y-slider"
                        type="range"
                        min="0"
                        max="100"
                        value={config.positionY}
                        onChange={(e) => {
                          setConfig(prev => ({ ...prev, positionY: parseInt(e.target.value) }));
                        }}
                        onMouseUp={() => saveHistory()}
                        onTouchEnd={() => saveHistory()}
                        className="w-full h-1 bg-zinc-200 rounded-lg appearance-none cursor-pointer accent-zinc-950"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Section 2: Color stops bar distribution */}
          <div className="bg-white border border-zinc-200 rounded-2xl p-5 shadow-sm space-y-4">
            <h2 className="text-xs font-mono font-bold tracking-wider uppercase text-zinc-400 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5" /> Distribución cromática
            </h2>
            
            <GradientSlider 
              stops={config.stops}
              selectedStopId={selectedStopId}
              onSelectStop={setSelectedStopId}
              onAddStop={handleAddStop}
              onUpdateStopPosition={handleUpdateStopPosition}
              onRemoveStop={handleRemoveStop}
            />
          </div>

          {/* Section 3: Advanced Color settings (for selected stop) */}
          {selectedStop && (
            <div className="bg-white border border-zinc-200 rounded-2xl p-5 shadow-sm space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-150">
              <h2 className="text-xs font-mono font-bold tracking-wider uppercase text-zinc-400 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5" /> Color Seleccionado
              </h2>

              <ColorPicker 
                color={selectedStop.color}
                opacity={selectedStop.opacity}
                onChangeColor={handleUpdateStopColor}
                onChangeOpacity={handleUpdateStopOpacity}
              />
            </div>
          )}

          {/* Section 4: Curated Presets & Randomizer */}
          <div className="bg-white border border-zinc-200 rounded-2xl p-5 shadow-sm">
            <Presets 
              onSelectPreset={handleSelectPreset}
              onRandomize={handleRandomize}
            />
          </div>
        </div>
      </main>

      {/* Floating alert/toast element */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-zinc-900 text-white font-medium text-xs py-2.5 px-4 rounded-xl shadow-lg flex items-center gap-2 border border-zinc-800"
          >
            <Check className="w-3.5 h-3.5 text-emerald-400" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
