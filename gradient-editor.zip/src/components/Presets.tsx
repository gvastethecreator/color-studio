import React from 'react';
import { Sparkles } from 'lucide-react';
import { GradientPreset, GradientStop } from '../types';

interface PresetsProps {
  onSelectPreset: (preset: GradientPreset) => void;
  onRandomize: () => void;
  id?: string;
}

// 12 exquisitely designed presets with modern color combinations and smooth color distribution
export const PRESETS_LIST: GradientPreset[] = [
  {
    name: 'Atardecer Aura',
    type: 'linear',
    angle: 45,
    stops: [
      { color: '#F27121', position: 0, opacity: 100 },
      { color: '#E94057', position: 50, opacity: 100 },
      { color: '#8A2387', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Brisa Marina',
    type: 'linear',
    angle: 135,
    stops: [
      { color: '#00c6ff', position: 0, opacity: 100 },
      { color: '#0072ff', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Cyberpunk',
    type: 'linear',
    angle: 90,
    stops: [
      { color: '#f72585', position: 0, opacity: 100 },
      { color: '#7209b7', position: 50, opacity: 100 },
      { color: '#4cc9f0', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Lavanda Suave',
    type: 'linear',
    angle: 180,
    stops: [
      { color: '#e0c3fc', position: 0, opacity: 100 },
      { color: '#8ec5fc', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Menta Fresca',
    type: 'linear',
    angle: 225,
    stops: [
      { color: '#a8ff78', position: 0, opacity: 100 },
      { color: '#78ffd6', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Aurora Boreal',
    type: 'linear',
    angle: 60,
    stops: [
      { color: '#0575E6', position: 0, opacity: 100 },
      { color: '#00F260', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Glow Radial',
    type: 'radial',
    angle: 0,
    shape: 'circle',
    positionX: 50,
    positionY: 50,
    stops: [
      { color: '#ffd1ff', position: 0, opacity: 100 },
      { color: '#f107a3', position: 60, opacity: 100 },
      { color: '#7b2cbf', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Eclipse Lunar',
    type: 'radial',
    angle: 0,
    shape: 'ellipse',
    positionX: 30,
    positionY: 30,
    stops: [
      { color: '#1f1c2c', position: 0, opacity: 100 },
      { color: '#928dab', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Remolino Cónico',
    type: 'conic',
    angle: 45,
    positionX: 50,
    positionY: 50,
    stops: [
      { color: '#ff007f', position: 0, opacity: 100 },
      { color: '#7f00ff', position: 33, opacity: 100 },
      { color: '#00ffff', position: 66, opacity: 100 },
      { color: '#ff007f', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Bronce Arena',
    type: 'linear',
    angle: 315,
    stops: [
      { color: '#E1B382', position: 0, opacity: 100 },
      { color: '#122620', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Oro Líquido',
    type: 'linear',
    angle: 15,
    stops: [
      { color: '#BF953F', position: 0, opacity: 100 },
      { color: '#FCF6BA', position: 25, opacity: 100 },
      { color: '#B38728', position: 50, opacity: 100 },
      { color: '#FBF5B7', position: 75, opacity: 100 },
      { color: '#AA771C', position: 100, opacity: 100 }
    ]
  },
  {
    name: 'Espacio Profundo',
    type: 'linear',
    angle: 120,
    stops: [
      { color: '#0f2027', position: 0, opacity: 100 },
      { color: '#203a43', position: 50, opacity: 100 },
      { color: '#2c5364', position: 100, opacity: 100 }
    ]
  }
];

export const Presets: React.FC<PresetsProps> = ({
  onSelectPreset,
  onRandomize,
  id = 'presets-panel'
}) => {
  // Helper to convert preset stops into inline preview style
  const getPresetPreviewStyle = (preset: GradientPreset) => {
    const stopsList = preset.stops.map(s => `${s.color} ${s.position}%`).join(', ');
    if (preset.type === 'linear') {
      return { background: `linear-gradient(${preset.angle}deg, ${stopsList})` };
    } else if (preset.type === 'radial') {
      return { background: `radial-gradient(${preset.shape || 'circle'} at 50% 50%, ${stopsList})` };
    } else {
      return { background: `conic-gradient(from 0deg at 50% 50%, ${stopsList})` };
    }
  };

  return (
    <div id={id} className="space-y-4">
      <div className="flex justify-between items-center">
        <span className="text-xs font-mono text-zinc-500">Diseños Curados</span>
        <button
          id={`${id}-random-btn`}
          type="button"
          onClick={onRandomize}
          className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-zinc-700 bg-zinc-100 hover:bg-zinc-200 active:scale-95 border border-zinc-200/50 rounded-lg transition-all duration-150 shadow-sm"
        >
          <Sparkles className="w-3 h-3 text-amber-500" />
          <span>Aleatorio</span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        {PRESETS_LIST.map((preset, idx) => (
          <button
            id={`${id}-preset-${idx}`}
            key={idx}
            type="button"
            onClick={() => onSelectPreset(preset)}
            className="group flex items-center gap-2.5 p-2 bg-white border border-zinc-200/60 rounded-xl hover:border-zinc-400 active:bg-zinc-50 text-left transition-all duration-150 shadow-sm overflow-hidden hover:shadow-md"
          >
            {/* Visual gradient preview circle */}
            <div 
              className="w-10 h-10 rounded-full border border-zinc-200/80 shadow-inner shrink-0 group-hover:scale-105 transition-transform"
              style={getPresetPreviewStyle(preset)}
            />
            {/* Text details */}
            <div className="min-w-0 flex-1">
              <span className="block text-xs font-semibold text-zinc-800 truncate leading-none mb-1">
                {preset.name}
              </span>
              <span className="block text-[9px] font-mono text-zinc-400 uppercase leading-none">
                {preset.type === 'conic' ? 'conic' : `${preset.type} ${preset.type === 'linear' ? `${preset.angle}°` : ''}`}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
