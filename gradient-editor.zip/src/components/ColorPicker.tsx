import React, { useState, useEffect, useRef } from 'react';
import { Pipette, Hash } from 'lucide-react';
import { hexToHsl, hslToHex, hexToRgb, rgbToHex } from '../utils/colorUtils';

interface ColorPickerProps {
  color: string; // Hex, e.g. "#4f46e5"
  opacity: number; // 0 to 100
  onChangeColor: (hex: string) => void;
  onChangeOpacity: (opacity: number) => void;
  id?: string;
}

export const ColorPicker: React.FC<ColorPickerProps> = ({
  color,
  opacity,
  onChangeColor,
  onChangeOpacity,
  id = 'color-picker'
}) => {
  const [hsl, setHsl] = useState({ h: 240, s: 100, l: 50 });
  const [hexInput, setHexInput] = useState(color);
  const boardRef = useRef<HTMLDivElement>(null);
  const isDraggingBoard = useRef(false);

  // Keep HSL state synchronized when the 'color' prop changes from outside (e.g. stop selection shifts)
  useEffect(() => {
    const calculatedHsl = hexToHsl(color);
    setHsl(calculatedHsl);
    setHexInput(color);
  }, [color]);

  // Handle changes made through manual input field
  const handleHexInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setHexInput(val);

    // If it is a valid hex color, trigger update
    const cleanHex = val.trim();
    if (/^#?[0-9A-Fa-f]{6}$/.test(cleanHex)) {
      const formattedHex = cleanHex.startsWith('#') ? cleanHex : `#${cleanHex}`;
      onChangeColor(formattedHex);
    } else if (/^#?[0-9A-Fa-f]{3}$/.test(cleanHex)) {
      const formattedHex = cleanHex.startsWith('#') ? cleanHex : `#${cleanHex}`;
      onChangeColor(formattedHex);
    }
  };

  // Browser EyeDropper API integration
  const handleEyeDropper = async () => {
    if (typeof window !== 'undefined' && 'EyeDropper' in window) {
      try {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const eyeDropper = new (window as any).EyeDropper();
        const result = await eyeDropper.open();
        if (result && result.sRGBHex) {
          onChangeColor(result.sRGBHex);
        }
      } catch (err) {
        console.warn('EyeDropper closed or failed:', err);
      }
    }
  };

  const hasEyeDropper = typeof window !== 'undefined' && 'EyeDropper' in window;

  // Handle 2D Saturation-Lightness Canvas interactions
  const updateColorFromBoard = (clientX: number, clientY: number) => {
    if (!boardRef.current) return;
    const rect = boardRef.current.getBoundingClientRect();
    
    // Saturation ranges 0 to 100
    const x = Math.max(0, Math.min(rect.width, clientX - rect.left));
    const s = Math.round((x / rect.width) * 100);

    // Lightness is mapped vertically (top is bright, bottom is dark)
    // To make it look like standard color pickers:
    // Brightness/value-like behavior can be simulated via HSL
    // Y maps to lightness (100% at the top left, 0% at the bottom, etc.)
    const y = Math.max(0, Math.min(rect.height, clientY - rect.top));
    const rawY = 1 - y / rect.height; // 0 to 1
    
    // An elegant mapping for HSL picker:
    // Lightness decreases as we go down. At the top, lightness is controlled by Saturation
    // Pure lightness is 50% at max saturation, and 100% at left top.
    // Let's use a standard intuitive HSL coordinate model:
    // s (saturation) = X percentage
    // l (lightness) = Y percentage * (100 - S/2)% or simple l = Y percentage
    const l = Math.round(rawY * 100);

    const newHex = hslToHex(hsl.h, s, l);
    onChangeColor(newHex);
    setHsl({ h: hsl.h, s, l });
  };

  const handleBoardMouseDown = (e: React.MouseEvent) => {
    isDraggingBoard.current = true;
    updateColorFromBoard(e.clientX, e.clientY);
    document.addEventListener('mousemove', handleGlobalMouseMove);
    document.addEventListener('mouseup', handleGlobalMouseUp);
  };

  const handleGlobalMouseMove = (e: MouseEvent) => {
    if (!isDraggingBoard.current) return;
    updateColorFromBoard(e.clientX, e.clientY);
  };

  const handleGlobalMouseUp = () => {
    isDraggingBoard.current = false;
    document.removeEventListener('mousemove', handleGlobalMouseMove);
    document.removeEventListener('mouseup', handleGlobalMouseUp);
  };

  // Adjust Hue slider
  const handleHueSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const h = parseInt(e.target.value);
    const newHex = hslToHex(h, hsl.s, hsl.l);
    onChangeColor(newHex);
    setHsl(prev => ({ ...prev, h }));
  };

  // Clean, premium design swatches
  const colorSwatches = [
    '#FF6B6B', '#FF8E53', '#FFD200', '#4EAF0A', '#00D2FC', 
    '#3062FC', '#8A2387', '#E94057', '#F27121', '#111827', 
    '#FFFFFF', '#9CA3AF'
  ];

  return (
    <div id={id} className="space-y-4">
      {/* 2D Color Board (Saturation vs Lightness) */}
      <div 
        ref={boardRef}
        onMouseDown={handleBoardMouseDown}
        className="relative h-36 w-full rounded-xl cursor-crosshair overflow-hidden select-none"
        style={{
          backgroundColor: `hsl(${hsl.h}, 100%, 50%)`,
          backgroundImage: `
            linear-gradient(to right, #fff, transparent),
            linear-gradient(to top, #000, transparent)
          `,
          backgroundBlendMode: 'multiply'
        }}
      >
        {/* Selector pointer */}
        <div 
          className="absolute h-4 w-4 -translate-x-2 translate-y-2 rounded-full border-2 border-white shadow-md pointer-events-none transition-all duration-75"
          style={{
            left: `${hsl.s}%`,
            bottom: `${hsl.l}%`,
            backgroundColor: color
          }}
        />
      </div>

      {/* Hue (Rainbow) Slider */}
      <div className="space-y-1.5">
        <div className="flex justify-between items-center text-xs font-mono text-zinc-500">
          <span>Tono (Hue)</span>
          <span>{hsl.h}°</span>
        </div>
        <div className="relative flex items-center">
          <input
            id={`${id}-hue-slider`}
            type="range"
            min="0"
            max="360"
            value={hsl.h}
            onChange={handleHueSliderChange}
            className="w-full h-3 rounded-full appearance-none cursor-pointer focus:outline-none"
            style={{
              background: 'linear-gradient(to right, #ff0000 0%, #ffff00 17%, #00ff00 33%, #00ffff 50%, #0000ff 67%, #ff00ff 83%, #ff0000 100%)'
            }}
          />
        </div>
      </div>

      {/* Opacity / Alpha Slider */}
      <div className="space-y-1.5">
        <div className="flex justify-between items-center text-xs font-mono text-zinc-500">
          <span>Opacidad</span>
          <span>{opacity}%</span>
        </div>
        <div className="relative h-3 rounded-full overflow-hidden flex items-center bg-zinc-200">
          {/* Transparency grid background */}
          <div 
            className="absolute inset-0 pointer-events-none opacity-40"
            style={{
              backgroundImage: 'conic-gradient(#ccc 0.25turn, transparent 0.25turn 0.5turn, #ccc 0.5turn 0.75turn, transparent 0.75turn)',
              backgroundSize: '8px 8px'
            }}
          />
          {/* Real color fade overlay */}
          <div 
            className="absolute inset-0 pointer-events-none"
            style={{
              background: `linear-gradient(to right, transparent, ${color})`
            }}
          />
          <input
            id={`${id}-opacity-slider`}
            type="range"
            min="0"
            max="100"
            value={opacity}
            onChange={(e) => onChangeOpacity(parseInt(e.target.value))}
            className="absolute inset-0 w-full h-full appearance-none bg-transparent cursor-pointer focus:outline-none"
          />
        </div>
      </div>

      {/* Color inputs (Hex Code & Eyedropper) */}
      <div className="flex gap-2">
        <div className="relative flex-1 flex items-center">
          <span className="absolute left-3 text-zinc-400">
            <Hash className="w-3.5 h-3.5" />
          </span>
          <input
            id={`${id}-hex-input`}
            type="text"
            value={hexInput}
            onChange={handleHexInputChange}
            placeholder="#000000"
            className="w-full pl-8 pr-3 py-2 text-sm font-mono text-zinc-800 bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:ring-1.5 focus:ring-zinc-950 focus:border-transparent focus:bg-white transition-all duration-150"
          />
          <div 
            className="absolute right-2.5 w-5 h-5 rounded border border-zinc-200/50 shadow-sm pointer-events-none"
            style={{ backgroundColor: color, opacity: opacity / 100 }}
          />
        </div>

        {hasEyeDropper && (
          <button
            id={`${id}-eyedropper`}
            type="button"
            onClick={handleEyeDropper}
            title="Seleccionar color de pantalla"
            className="p-2 text-zinc-600 bg-zinc-50 border border-zinc-200 rounded-lg hover:bg-zinc-100 active:bg-zinc-200/70 transition-colors duration-150 flex items-center justify-center"
          >
            <Pipette className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Quick Color Swatches */}
      <div className="space-y-1.5">
        <span className="block text-xs font-mono text-zinc-500">Muestras</span>
        <div className="grid grid-cols-6 gap-2">
          {colorSwatches.map((swatch, idx) => (
            <button
              id={`${id}-swatch-${idx}`}
              key={swatch}
              type="button"
              onClick={() => {
                onChangeColor(swatch);
                setHexInput(swatch);
              }}
              className="group relative h-7 rounded-lg border border-zinc-200/50 hover:scale-105 active:scale-95 transition-all duration-150 shadow-sm overflow-hidden"
              style={{ backgroundColor: swatch }}
              title={swatch}
            >
              {/* Tooltip or high contrast ring on hover */}
              <span className="absolute inset-0 border-2 border-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
