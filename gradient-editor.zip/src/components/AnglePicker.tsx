import React, { useRef } from 'react';
import { RefreshCw } from 'lucide-react';

interface AnglePickerProps {
  angle: number; // 0-360
  onChangeAngle: (angle: number) => void;
  id?: string;
}

export const AnglePicker: React.FC<AnglePickerProps> = ({
  angle,
  onChangeAngle,
  id = 'angle-picker'
}) => {
  const dialRef = useRef<HTMLDivElement>(null);

  const calculateAngle = (clientX: number, clientY: number) => {
    if (!dialRef.current) return;
    const rect = dialRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const deltaX = clientX - centerX;
    const deltaY = clientY - centerY;

    // Convert radians to degrees and align to CSS gradient spec (0deg is North, clockwise)
    let degrees = Math.round((Math.atan2(deltaY, deltaX) * 180) / Math.PI) + 90;
    if (degrees < 0) degrees += 360;
    
    onChangeAngle(degrees % 360);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    calculateAngle(e.clientX, e.clientY);

    const handleMouseMove = (moveEvent: MouseEvent) => {
      calculateAngle(moveEvent.clientX, moveEvent.clientY);
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 0) return;
    calculateAngle(e.touches[0].clientX, e.touches[0].clientY);

    const handleTouchMove = (moveEvent: TouchEvent) => {
      if (moveEvent.touches.length === 0) return;
      calculateAngle(moveEvent.touches[0].clientX, moveEvent.touches[0].clientY);
    };

    const handleTouchEnd = () => {
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
    };

    document.addEventListener('touchmove', handleTouchMove, { passive: true });
    document.addEventListener('touchend', handleTouchEnd);
  };

  // Standard angles for quick-snaps
  const quickAngles = [
    { label: '↑ 0°', value: 0 },
    { label: '→ 90°', value: 90 },
    { label: '↓ 180°', value: 180 },
    { label: '← 270°', value: 270 }
  ];

  return (
    <div id={id} className="space-y-4">
      <div className="flex justify-between items-center text-xs font-mono text-zinc-500">
        <span>Ángulo de dirección</span>
        <span>{angle}°</span>
      </div>

      <div className="flex items-center gap-6">
        {/* Visual Dial */}
        <div
          ref={dialRef}
          onMouseDown={handleMouseDown}
          onTouchStart={handleTouchStart}
          className="relative w-20 h-20 rounded-full border border-zinc-200 bg-white shadow-sm flex items-center justify-center cursor-pointer select-none active:scale-98 transition-transform"
        >
          {/* Degree grid tick lines (subtle background helper) */}
          <div className="absolute inset-2 rounded-full border border-zinc-100 border-dashed pointer-events-none" />
          
          {/* Inner needle / pointer hub */}
          <div className="absolute w-1.5 h-1.5 rounded-full bg-zinc-800" />
          
          {/* Pointer needle line */}
          <div 
            className="absolute top-0 bottom-1/2 w-0.5 origin-bottom bg-zinc-800"
            style={{ transform: `rotate(${angle}deg)` }}
          >
            {/* Visual handle ball */}
            <div className="absolute -top-1 -left-[3px] w-2 h-2 rounded-full bg-zinc-950 border border-white shadow-sm" />
          </div>

          {/* Compass labels for N S E W */}
          <span className="absolute top-1 text-[8px] font-mono text-zinc-300 pointer-events-none">N</span>
          <span className="absolute bottom-1 text-[8px] font-mono text-zinc-300 pointer-events-none">S</span>
          <span className="absolute right-1 text-[8px] font-mono text-zinc-300 pointer-events-none">E</span>
          <span className="absolute left-1 text-[8px] font-mono text-zinc-300 pointer-events-none">O</span>
        </div>

        {/* Precise inputs and Quick Select buttons */}
        <div className="flex-1 space-y-2">
          {/* Manual Input Box */}
          <div className="flex items-center gap-2 bg-zinc-50 border border-zinc-200 rounded-lg px-3 py-1.5 shadow-sm max-w-[120px]">
            <input
              id={`${id}-manual-input`}
              type="number"
              min="0"
              max="359"
              value={angle}
              onChange={(e) => {
                const val = (parseInt(e.target.value) || 0) % 360;
                onChangeAngle(val < 0 ? val + 360 : val);
              }}
              className="w-full text-sm font-mono font-medium focus:outline-none bg-transparent text-zinc-800"
            />
            <span className="text-sm font-mono text-zinc-400">°</span>
          </div>

          {/* Quick preset buttons */}
          <div className="grid grid-cols-2 gap-1.5">
            {quickAngles.map((qa) => (
              <button
                id={`${id}-quick-angle-${qa.value}`}
                key={qa.value}
                type="button"
                onClick={() => onChangeAngle(qa.value)}
                className={`px-2 py-1 text-[11px] font-mono rounded border transition-colors ${
                  angle === qa.value
                    ? 'bg-zinc-950 text-white border-zinc-950'
                    : 'bg-white text-zinc-600 border-zinc-200 hover:bg-zinc-50 hover:text-zinc-900'
                }`}
              >
                {qa.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
