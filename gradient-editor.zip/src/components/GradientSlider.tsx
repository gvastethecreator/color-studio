import React, { useRef } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { GradientStop } from '../types';

interface GradientSliderProps {
  stops: GradientStop[];
  selectedStopId: string | null;
  onSelectStop: (id: string) => void;
  onAddStop: (position: number) => void;
  onUpdateStopPosition: (id: string, position: number) => void;
  onRemoveStop: (id: string) => void;
}

export const GradientSlider: React.FC<GradientSliderProps> = ({
  stops,
  selectedStopId,
  onSelectStop,
  onAddStop,
  onUpdateStopPosition,
  onRemoveStop
}) => {
  const trackRef = useRef<HTMLDivElement>(null);

  // Helper to calculate linear stop background (always horizontal for the slider track preview)
  const getSliderTrackGradient = () => {
    const sorted = [...stops].sort((a, b) => a.position - b.position);
    const parts = sorted.map(stop => {
      // Return rgb formatting with opacity
      const opacityVal = stop.opacity / 100;
      return `${stop.color} ${stop.position}%`;
    });
    return `linear-gradient(to right, ${parts.join(', ')})`;
  };

  // Click on the track to add a stop or select a stop
  const handleTrackClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!trackRef.current) return;
    const rect = trackRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const position = Math.max(0, Math.min(100, Math.round((clickX / rect.width) * 100)));

    // Only add if we did not click directly on an existing handle
    // We can assume if the user clicks and no drag is active, we add a stop
    // Let's check if the click was close to an existing stop.
    const threshold = 3; // within 3% range
    const closeStop = stops.find(stop => Math.abs(stop.position - position) < threshold);

    if (closeStop) {
      onSelectStop(closeStop.id);
    } else {
      onAddStop(position);
    }
  };

  // Drag stop handler (supports both mouse and touch)
  const handleStopStartDrag = (id: string, startEvent: React.MouseEvent | React.TouchEvent) => {
    startEvent.stopPropagation();
    onSelectStop(id);

    const handleMove = (moveEvent: MouseEvent | TouchEvent) => {
      if (!trackRef.current) return;
      const rect = trackRef.current.getBoundingClientRect();
      
      let clientX = 0;
      if ('touches' in moveEvent) {
        if (moveEvent.touches.length === 0) return;
        clientX = moveEvent.touches[0].clientX;
      } else {
        clientX = moveEvent.clientX;
      }

      const offset = clientX - rect.left;
      const position = Math.max(0, Math.min(100, Math.round((offset / rect.width) * 100)));
      onUpdateStopPosition(id, position);
    };

    const handleEnd = () => {
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleEnd);
      document.removeEventListener('touchmove', handleMove);
      document.removeEventListener('touchend', handleEnd);
    };

    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleEnd);
    document.addEventListener('touchmove', handleMove, { passive: true });
    document.addEventListener('touchend', handleEnd);
  };

  // Sort stops to draw them correctly but keep their reference IDs intact
  const sortedStops = [...stops].sort((a, b) => a.position - b.position);
  const activeStop = stops.find(s => s.id === selectedStopId);

  return (
    <div id="gradient-slider-container" className="space-y-4">
      <div className="flex justify-between items-center text-xs font-mono text-zinc-500">
        <span>Distribución de colores</span>
        <span>{stops.length} puntos</span>
      </div>

      {/* The slider widget */}
      <div className="relative pt-2 pb-6 px-1">
        {/* Underlay checkered track */}
        <div 
          ref={trackRef}
          onClick={handleTrackClick}
          className="relative h-6 w-full rounded-lg border border-zinc-200/80 cursor-pointer overflow-hidden shadow-inner flex items-center"
          style={{
            backgroundImage: 'conic-gradient(#eee 0.25turn, transparent 0.25turn 0.5turn, #eee 0.5turn 0.75turn, transparent 0.75turn)',
            backgroundSize: '10px 10px'
          }}
        >
          {/* Active color gradient overlay */}
          <div 
            className="absolute inset-0"
            style={{ background: getSliderTrackGradient() }}
          />
        </div>

        {/* Dynamic Stops Pins */}
        {stops.map(stop => {
          const isSelected = stop.id === selectedStopId;
          return (
            <div
              id={`stop-pin-${stop.id}`}
              key={stop.id}
              className={`absolute top-5 -translate-x-1/2 group cursor-grab active:cursor-grabbing select-none ${isSelected ? 'z-30' : 'z-20'}`}
              style={{ left: `${stop.position}%` }}
              onMouseDown={(e) => handleStopStartDrag(stop.id, e)}
              onTouchStart={(e) => handleStopStartDrag(stop.id, e)}
            >
              {/* Pin design */}
              <div className="flex flex-col items-center">
                {/* Visual pointer pointer */}
                <div 
                  className={`w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent transition-colors ${
                    isSelected ? 'border-b-[8px] border-b-zinc-950' : 'border-b-[8px] border-b-zinc-400 group-hover:border-b-zinc-600'
                  }`}
                />
                {/* Pin Color circular bubble */}
                <div 
                  className={`w-6 h-6 rounded-full border-2 bg-white flex items-center justify-center shadow-md -mt-0.5 transition-all ${
                    isSelected ? 'scale-110 ring-2 ring-zinc-950 ring-offset-1 border-zinc-900' : 'border-zinc-300 group-hover:scale-105'
                  }`}
                >
                  <div 
                    className="w-4 h-4 rounded-full border border-black/10 shadow-inner"
                    style={{ 
                      backgroundColor: stop.color,
                      opacity: stop.opacity / 100 
                    }}
                  />
                </div>
                {/* Numeric percent position tooltip */}
                <span className="mt-1 text-[9px] font-mono font-medium text-zinc-500 opacity-0 group-hover:opacity-100 transition-opacity bg-zinc-950 text-white px-1 rounded shadow-sm">
                  {stop.position}%
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active stop helper settings */}
      {activeStop && (
        <div id="active-stop-panel" className="bg-zinc-50/50 border border-zinc-200/60 rounded-xl p-3 flex justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-8 h-8 rounded-lg border border-zinc-300 shadow-sm flex items-center justify-center"
              style={{
                backgroundImage: 'conic-gradient(#eee 0.25turn, transparent 0.25turn 0.5turn, #eee 0.5turn 0.75turn, transparent 0.75turn)',
                backgroundSize: '6px 6px'
              }}
            >
              <div 
                className="w-full h-full rounded-lg"
                style={{ backgroundColor: activeStop.color, opacity: activeStop.opacity / 100 }}
              />
            </div>
            <div>
              <span className="block text-xs font-medium text-zinc-800">
                Punto seleccionado
              </span>
              <span className="block text-[10px] font-mono text-zinc-500">
                Posición: {activeStop.position}% • Opacidad: {activeStop.opacity}%
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Direct Position Slider inside sub-editor */}
            <div className="flex items-center gap-1.5 bg-white border border-zinc-200/80 rounded-lg px-2 py-1 shadow-sm">
              <span className="text-[10px] font-mono text-zinc-400">POS</span>
              <input
                id="active-stop-position-input"
                type="number"
                min="0"
                max="100"
                value={activeStop.position}
                onChange={(e) => {
                  const val = Math.max(0, Math.min(100, parseInt(e.target.value) || 0));
                  onUpdateStopPosition(activeStop.id, val);
                }}
                className="w-8 text-center text-xs font-mono font-medium focus:outline-none text-zinc-800 bg-transparent"
              />
              <span className="text-[10px] font-mono text-zinc-400">%</span>
            </div>

            {/* Delete button (only if there are > 2 stops) */}
            <button
              id="delete-stop-button"
              type="button"
              disabled={stops.length <= 2}
              onClick={() => onRemoveStop(activeStop.id)}
              className={`p-2 rounded-lg border shadow-sm transition-all duration-150 ${
                stops.length > 2
                  ? 'bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700 active:scale-95 border-red-200'
                  : 'bg-zinc-100 text-zinc-300 border-zinc-200 cursor-not-allowed'
              }`}
              title="Eliminar punto de color (mínimo 2)"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* If no stop is selected but we want to add one quickly */}
      {!activeStop && (
        <div id="no-stop-panel" className="bg-zinc-50/50 border border-zinc-200/60 rounded-xl p-3 text-center">
          <span className="text-xs text-zinc-500">
            Haz clic en la barra para seleccionar o añadir un nuevo punto de color.
          </span>
        </div>
      )}
    </div>
  );
};
